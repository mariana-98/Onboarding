package org.trabalho_final.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.trabalho_final.modelo.Compromisso;
import org.trabalho_final.modelo.Contato;
import org.trabalho_final.modelo.Usuario;
import org.trabalho_final.repositorio.CompromissoRepositorio;
import org.trabalho_final.repositorio.ContatoRepositorio;

@Controller
public class CompromissoController {
	private CompromissoRepositorio repositorio;
	@Autowired
	ContatoRepositorio crepo;
	@Autowired
	public CompromissoController(CompromissoRepositorio repositorio) {
		this.repositorio = repositorio;
	}
	
	@RequestMapping("compromissos")
	public String compromissoPage(Model model, HttpSession sessao) {
		Usuario usuario = (Usuario) sessao.getAttribute("usuario");
		if(usuario != null){
			model.addAttribute("compromissos", repositorio.getCompromissos(usuario));
		}else {
			return "redirect:login";
		}
		return "compromissos";
	}
	
	@RequestMapping("novoCompromisso")
	public String compromissoForm(Model model, HttpSession sessao) {
		Usuario usuario = (Usuario) sessao.getAttribute("usuario");
		if(usuario == null)
			return "redirect:login";
		model.addAttribute("contatos", crepo.getContato(usuario, "%"));
		return "novoCompromisso";
	}
	
	@RequestMapping("alterarCompromisso")
	public String alterarCompromisso(Model model, Compromisso cont, HttpSession sessao) {
		Usuario usuario = (Usuario) sessao.getAttribute("usuario");
		Compromisso compromisso = repositorio.getCompromissoById(cont.getId());
		model.addAttribute("compromisso", compromisso);
		model.addAttribute("contatos", crepo.getContato(usuario, "%"));
		return "alterarCompromisso";
	}
	
	@Transactional
	@RequestMapping(value = "gravarCompromisso", method = RequestMethod.POST)
	public String gravarCompromisso(Compromisso compromisso, HttpSession sessao) {
		Usuario usuario = (Usuario) sessao.getAttribute("usuario");
		if(usuario != null) {
			compromisso.setUsuario(usuario);
			repositorio.cadastrar(compromisso);	
		}else {
			return "redirect:login";
		}
		
		return "redirect:compromissos";
	}
	
	@Transactional
	@RequestMapping(value = "salvarCompromisso", method = RequestMethod.POST)
	public String salvarContato(Compromisso compromisso, HttpSession sessao) {
		Usuario usuario = (Usuario) sessao.getAttribute("usuario");
		if(usuario != null) {
			compromisso.setUsuario(usuario);
			repositorio.update(compromisso);
		}else {
			return "redirect:login";
		}
		
		return "redirect:compromissos";
	}
	
	@Transactional
	@RequestMapping("removerCompromisso")
	public String removerContato(Compromisso compromisso, HttpSession sessao) {
		Usuario usuario = (Usuario) sessao.getAttribute("usuario");
		if(usuario != null) {
			Compromisso comp = repositorio.getCompromissoById(compromisso.getId());
			repositorio.remove(comp);
		}else {
			return "redirect:login";
		}
		
		return "redirect:compromissos";
	}
}
