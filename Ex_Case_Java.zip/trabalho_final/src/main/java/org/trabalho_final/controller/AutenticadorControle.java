package org.trabalho_final.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.trabalho_final.modelo.Usuario;
import org.trabalho_final.repositorio.UsuarioRepositorio;

@Controller
public class AutenticadorControle {
	
	private UsuarioRepositorio repositorio;
	
	@Autowired
	public AutenticadorControle(UsuarioRepositorio repositorio) {
		this.repositorio = repositorio;
	}
	
	@RequestMapping("login")
	public String loginForm(HttpSession sessao) {
		Usuario user = (Usuario) sessao.getAttribute("usuario");
		if(user != null) {
			return "redirect:inicio";
		}
		return "login";
	}
	@RequestMapping("logout")
	public String logoutForm(HttpSession sessao) {
		sessao.removeAttribute("usuario");
		return "redirect:login";
	}
	@RequestMapping("inicio")
	public String inicio(HttpSession sessao){
		Usuario user = (Usuario)sessao.getAttribute("usuario");
		if(user != null)
			return "sucesso";
		else
			return "redirect:login";
	}
	
	
	@RequestMapping(value = "autentica", method = RequestMethod.POST)
	public String autenticar(Usuario usuario, HttpSession sessao) {
		Usuario user = repositorio.autenticar(usuario);
		if(user != null) {
			usuario.setId(user.getId());
			sessao.setAttribute("usuario", usuario);
			return "sucesso";
		}
		return "redirect:login";
	}
	
	

}
