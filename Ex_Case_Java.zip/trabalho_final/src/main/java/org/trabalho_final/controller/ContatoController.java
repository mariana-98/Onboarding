package org.trabalho_final.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.trabalho_final.modelo.Contato;
import org.trabalho_final.modelo.Usuario;
import org.trabalho_final.repositorio.ContatoRepositorio;

@Controller
public class ContatoController {
	private ContatoRepositorio repositorio;
	
	@Autowired
	public ContatoController(ContatoRepositorio repositorio) {
		this.repositorio = repositorio;
	}
	
	@RequestMapping("contatos")
	public String contatoPage(Model model,String nome, HttpSession sessao) {
		Usuario usuario = (Usuario) sessao.getAttribute("usuario");
		String param = "%";
		if(usuario != null){
			if(nome != null)
				param += nome;
			model.addAttribute("contatos", repositorio.getContato(usuario, param));
		}else {
			return "redirect:login";
		}
		return "contatos";
	}
	
	@RequestMapping("novoContato")
	public String contatoForm() {
		return "novoContato";
	}
	
	@RequestMapping("alterarContato")
	public String alterarContato(Model model, Contato cont, HttpSession sessao) {
		Usuario usuario = (Usuario)  sessao.getAttribute("usuario");
		if(usuario == null)
			return "redirect:login";
		Contato contato = repositorio.getContatoById(cont.getId());
		model.addAttribute("contato", contato);
		return "alterarContato";
	}
	@Transactional
	@RequestMapping(value = "gravarContato", method = RequestMethod.POST)
	public String gravarContato(Contato contato, HttpSession sessao) {
		Usuario usuario = (Usuario) sessao.getAttribute("usuario");
		if(usuario != null) {
			contato.setUsuario(usuario);
			repositorio.cadastrar(contato);	
		}else {
			return "redirect:login";
		}
		
		return "redirect:contatos";
	}
	@Transactional
	@RequestMapping(value = "salvarContato", method = RequestMethod.POST)
	public String salvarContato(Contato contato, HttpSession sessao) {
		Usuario usuario = (Usuario) sessao.getAttribute("usuario");
		if(usuario != null) {
			contato.setUsuario(usuario);
			repositorio.update(contato);
		}else {
			return "redirect:login";
		}
		
		return "redirect:contatos";
	}
	@Transactional
	@RequestMapping("removerContato")
	public String removerContato(Contato contato, HttpSession sessao) {
		Usuario usuario = (Usuario) sessao.getAttribute("usuario");
		if(usuario != null) {
			Contato cont = repositorio.getContatoById(contato.getId());
			repositorio.remove(cont);
		}else {
			return "redirect:login";
		}
		
		return "redirect:contatos";
	}
}
