package org.trabalho_final.repositorio;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.trabalho_final.modelo.Usuario;

@Repository
public class UsuarioRepositorio {
	
	@PersistenceContext
	private EntityManager manager;
	
	public void cadastrar(Usuario usuario) {
		manager.persist(usuario);
	}
	
	public Usuario autenticar(Usuario usuario) {
		TypedQuery query = manager.createQuery("select u from Usuario u where u.login = ?1 and u.senha = ?2", Usuario.class);
		query.setParameter(1, usuario.getLogin()).setParameter(2, usuario.getSenha());
		try {
			usuario = (Usuario) query.getSingleResult();
			return usuario;
		} catch (NoResultException e) {
			return null;
		}
	}

}
