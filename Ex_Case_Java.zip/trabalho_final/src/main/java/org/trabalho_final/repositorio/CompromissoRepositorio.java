package org.trabalho_final.repositorio;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.trabalho_final.modelo.Compromisso;
import org.trabalho_final.modelo.Usuario;

@Repository
public class CompromissoRepositorio {
	@PersistenceContext
	private EntityManager manager;
	
	public void cadastrar(Compromisso compromisso) {
		manager.persist(compromisso);
	}
	
	public List<Compromisso> getCompromissos(Usuario usuario){
		TypedQuery<Compromisso> query = manager.createQuery("select c from Compromisso c where c.usuario.id = ?1", Compromisso.class);
		query.setParameter(1, usuario.getId());
		return query.getResultList();
	}
	
	public Compromisso getCompromissoById(int id) {
		TypedQuery<Compromisso> query = manager.createQuery("select c from Compromisso c where c.id = ?1", Compromisso.class);
		query.setParameter(1, id);
		
		return query.getSingleResult();
	}
	
	public void remove(Compromisso compromisso) {
		manager.remove(compromisso);
	}
	
	public void update(Compromisso compromisso) {
		manager.merge(compromisso);
	}
}
