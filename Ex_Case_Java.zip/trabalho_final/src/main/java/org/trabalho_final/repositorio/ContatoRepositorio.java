package org.trabalho_final.repositorio;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.trabalho_final.modelo.Contato;
import org.trabalho_final.modelo.Usuario;

@Repository
public class ContatoRepositorio {
	@PersistenceContext
	private EntityManager manager;
	
	public void cadastrar(Contato contato) {
		manager.persist(contato);
	}
	
	public List<Contato> getContato(Usuario usuario, String nome) {
		TypedQuery<Contato> query = manager.createQuery("select c from Contato c where c.usuario.id = ?1 and nome like ?2", Contato.class); 
		query.setParameter(1, usuario.getId()).setParameter(2, nome);
		
		List<Contato> contatos = query.getResultList();
		return contatos;
	}
	
	public Contato getContatoById(int id) {
		TypedQuery<Contato> query = manager.createQuery("select c from Contato c where c.id = ?1", Contato.class);
		query.setParameter(1, id);
		
		Contato contato = query.getSingleResult();
		return contato;
	}
	
	public void update(Contato contato) {
		manager.merge(contato);
	}
	
	public void remove(Contato contato) {
		manager.remove(contato);
	}
}
