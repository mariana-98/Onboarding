package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTester {
	public static void main (String args[]) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\User\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();  
		 
	    driver.navigate().to("https://www.google.com/");  

	    WebElement m=driver.findElement(By.name("q"));
	    // WebElement m1=driver.findElement(By.name("btnK"));
	    m.sendKeys("amdocs");
	    // type enter with sendKeys method and pass Keys.RETURN
	    m.sendKeys(Keys.RETURN);
	}
}
