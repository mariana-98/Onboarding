package com.junit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ SquareUnit.class, SumUnit.class })
public class AllTests {
	
	// We can use these annotations here to put anything before or after the test cases.
	@BeforeClass 
    public static void setUpClass() {      
        System.out.println("Master setup");
    }
	
	@AfterClass
	public static void finishClass() {
		System.out.println("End testing");
	}
}
