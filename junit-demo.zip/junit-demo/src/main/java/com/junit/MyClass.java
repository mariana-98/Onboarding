package com.junit;

public class MyClass {
	public int getSquare(int n) {
        return n*n;
    }
	
	public int getSum(int n, int m) {
		return n+m;
	}
}
