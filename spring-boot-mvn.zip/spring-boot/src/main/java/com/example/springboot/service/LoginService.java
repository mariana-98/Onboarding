package com.example.springboot.service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
	
	public boolean validateUser(String userid, String password) {
        return userid.equalsIgnoreCase("Isaac")
                && password.equalsIgnoreCase("pass@word1");
    }

}
